***************************************************************
** readme file associated with manuscript: MAN:NO **
***************************************************************

*This dataset contains individual movement trajectories for shoals of guppies (Poecilia reticulata) moving inside a square tank of side length 60cm.

*All data collected and prepared by Nikolai W.F. Bode who should also be contacted with questions (nikolai.bode@cantab.net).

*The dataset contains 26 files in addition to "readme.txt" which can be found in the archive "data.zip".

****************

The empirical data is contained in 26 plain text files.
Each file contains the movement trajectories for 10 individuals.
Three rows constitute the information obtained from one frame of the recorded video (10 frames/s).
The first two rows for each frame contain the x- and y-coordinates of individual positions and the third row contains the angle of the vector between two consecutive positions relative to the x-axis for one individual.
Within rows, the individual-specific entries are separated by commas.
Units: x- and y-coordinates in pixels, angles in radians.

The files "empirical_data_fmX.txt" (X=1,2,3,...,12) contain movement trajectories for all-female groups.

The files "empirical_data_mlX.txt" (X=1,2,3,...,14) contain movement trajectories for all-male groups.


Target coordinates used in the analysis were (x,y) = (350,500).
See associated publication for additional information on the analysis and data.

****************






